const express = require('express');
const mongoose = require('mongoose');
const userRoutes = require('./routes/users'); // Ensure the correct path to your routes
const app = express();
const cors = require('cors');

// Middleware
app.use(express.json());
app.use(cors()); // Cross-Origin Resource Sharing enabled

// Route for users
app.use('/api/users', userRoutes); // Routes will start with /api/users

// MongoDB connection
const mongoURI = 'mongodb+srv://amaurysbiz9519:cHeAHL51HlX0zIrS@cluster0.hgiak.mongodb.net/Twizzle?retryWrites=true&w=majority&appName=Cluster0';
mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch((err) => console.error('Error connecting to MongoDB:', err));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
