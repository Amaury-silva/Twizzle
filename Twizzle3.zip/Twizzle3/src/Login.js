import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await fetch('http://localhost:5000/api/users/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });
    console.error(response);

    
  
    if (response.ok) {
      const data = await response.json();
    
      // Store the token in localStorage
      localStorage.setItem('token', data.token);
      navigate('/home');
    } else {
      setError('Error during login, please try again');
    }
  };
  
  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Login</h2>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <div>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div className="login-buttons">
          <button type="submit">Log in</button>
          <button type="button" className="register-button" onClick={() => navigate('/register')}>Register</button>
        </div>
        <div>
          <a href="/forgot-password" className="forgot-password">Forgot Password?</a>
        </div>
      </form>
    </div>
  );
};

export default Login;
