import React from 'react';
import './index.css'; // for styling

function Settings() {
  return (
    <div>
      <h1>Settings</h1>
      <p>Welcome to your settings. Here's a quick overview of your activity.</p>
    </div>
  );
}

export default Settings;
