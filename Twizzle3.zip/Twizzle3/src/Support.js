import React from 'react';

function Support() {
  return (
    <div>
      <h1>Support</h1>
      <p>Welcome to your support. Here's a quick overview of your activity.</p>
    </div>
  );
}

export default Support;
