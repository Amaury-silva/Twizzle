import React from 'react';

function UserProfile() {
  return (
    <div>
      <h1>User Profile</h1>
      <p>Welcome to your dashboard. Here's a quick overview of your activity.</p>
    </div>
  );
}

export default UserProfile;
