// src/components/DeleteUser.js
// This component allows deleting a user by their ID

import React from 'react';
import axios from 'axios';

const DeleteUser = ({ userId }) => {
  // Function to handle user deletion
  const handleDelete = async () => {
    try {
      // Send a DELETE request to remove the user by ID
      const res = await axios.delete(`/api/users/${userId}`);
      alert(res.data.message); // Alert success message
    } catch (error) {
      console.error('Error deleting user:', error.response.data.message);
    }
  };

  return (
    <button onClick={handleDelete}>Delete User</button>
  );
};

export default DeleteUser;
