import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Home.css';

const Home = ({ user }) => {
  const [data, setData] = useState({ followers: 0, engagementRate: '', scheduledPosts: 0 });

  // Fetching the analytics data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/analytics');
        setData(response.data);
      } catch (error) {
        console.error('Error fetching analytics data:', error);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="home-container">
      <h1>Welcome back, {user}!</h1> {/* Username dynamically displayed */}
      <div className="analytics-overview">
        <h2>Your Analytics Overview</h2>
        <p>Total Followers: {data.followers}</p>
        <p>Engagement Rate: {data.engagementRate}</p>
        <p>Scheduled Posts: {data.scheduledPosts}</p>
      </div>
    </div>
  );
};

export default Home;
