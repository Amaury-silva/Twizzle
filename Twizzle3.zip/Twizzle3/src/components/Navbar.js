import React from 'react';

function Navbar() {
  return (
    <div>
      {/* Navbar code */}
    </div>
  );
}

export default Navbar;
