import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Profile.css';

const Profile = ({ user }) => {
  const [profileData, setProfileData] = useState({ username: '', bio: '', email: '', profilePic: '' });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/profile');
        setProfileData(response.data);
      } catch (error) {
        console.error('Error fetching profile data:', error);
      }
    };
    fetchProfile();
  }, []);

  return (
    <div className="profile-container">
      <h1>Profile: {user}</h1>
      <p>Bio: {profileData.bio}</p>
      <p>Email: {profileData.email}</p>
      <img src={profileData.profilePic || 'https://via.placeholder.com/150'} alt="Profile" />
    </div>
  );
};

export default Profile;
