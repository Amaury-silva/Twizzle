// src/components/UpdateUser.js
// This component allows updating a user's email

import React, { useState } from 'react';
import axios from 'axios';

const UpdateUser = ({ userId }) => {
  const [email, setEmail] = useState('');

  // Function to handle form submission for updating email
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      // Send a PUT request to update the user's email
      const res = await axios.put(`/api/users/${userId}`, { email });
      alert(res.data.message); // Alert success message
    } catch (error) {
      console.error('Error updating user:', error.response.data.message);
    }
  };

  return (
    <form onSubmit={handleUpdate}>
      <h2>Update User</h2>
      <label>New Email:</label>
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <button type="submit">Update Email</button>
    </form>
  );
};

export default UpdateUser;
